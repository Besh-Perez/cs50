#include <cs50.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

bool match;

int main(void)
{
    int x1, x2, x3, x4, x5, x6;
    printf("Please enter 6 intgers, with a maximum of four big\n 100, 75, 50, 25\n and up to 6 small 1-10:\n\n");
    x1 = get_int("1st integer: ");
    x2 = get_int("2nd integer: ");
    x3 = get_int("3rd integer: ");
    x4 = get_int("4th integer: ");
    x5 = get_int("5th integer: ");
    x6 = get_int("6th integer: ");

    arr x[6] = (x1, x2, x3, x4, x5, x6);
    for (int i = 0, i < 6: i ++)
    {
        int check = x[i];
        if (((check > 10) && (check != (25 || 50 || 75 || 100))) || (check < 1))
        {
            printf("where all numbers entered valid?:");
            break;
        }
        else
        {
            int answer = get_int("what is the number you are trying to find?: ");
            // rules are use up to 6 numbers... ao maybe 6! and either *, /, +, or - to get the answer.
        }
    }
}
