from cs50 import get_string

numbers = list()

def check(x):
    if (x < 1):
        print("only positive numbers are allowed")
    elif ( x < 11 and x > 25):
        print("only 25, 50, 75 or 100 are acceptable big numbers")
    elif (x > 25 and x < 50):
        print("only 25, 50, 75 or 100 are acceptable big numbers")
    elif (x > 50 and x < 75):
        print("only 25, 50, 75 or 100 are acceptable big numbers")
    elif (x > 75 and x < 100):
        print("only 25, 50, 75 or 100 are acceptable big numbers")
    elif (x > 100):
        print("only 25, 50, 75 or 100 are acceptable big numbers")
    else:
        return x


while len(numbers) < 6:
    i = 6
    nums = input(f"enter {i} countdown numbers: ")
    nums = int(nums)
    numbers.append(check(nums))
    i = i - 1

print(numbers.sort())