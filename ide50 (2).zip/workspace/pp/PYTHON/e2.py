sumn =  1000
for a in range(sumn/3):
    for b in range(sumn/2):
        for c in range (sumn):
            abc = []
            if(a**2 + b**2 = c**2 and a + b + c = sumn):
                abc.append(a)
                abc.append(b)
                abc.append(c)
print(abc)