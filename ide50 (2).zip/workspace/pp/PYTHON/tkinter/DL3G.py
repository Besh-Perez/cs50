from tkinter import *
from tkinter.ttk import combobox

window = Tk()

def heat(damage, profit):
    i = ((damage * 20 + profit * 0.5)**(0.5))
    return i

def purchase(ca, qty, co):
    cost1 = co * qty
    if cost1 <  ca:
        for i in range(qty):
            ca -= co
            product += 1
            return ca

def heal(health, cash):
    health = 100 - health
    if heat > 0 and health > 0:
        cost2 = (1 + (heat / 20))* health * 2
        if cash > cost2:
            cash -= cost2
            health = 100
            return health, cash

#titles
l1 = Label(window, text = "Day")
l1.grid(row = 0, column = 0)

l1 = Label(window, text = "Cash")
l1.grid(row = 1, column = 0)

l1 = Label(window, text = "Assets")
l1.grid(row = 2, column = 0)

l1 = Label(window, text = "Drugs")
l1.grid(row = 3, column = 0)

l1 = Label(window, test = "Quantity")
l1.grid(row = 4, column = 0)

HP = 100
BA = 0
spend_text = 0
cash_text = 500
i = 0
# output/ input
day_text = i
e1 = Entry(window, textvariable = day_text)
e1.grid(row = 0. column = 1)

cash_text = cash_text - spend_text
e2 = Entry(text_variable = cash_text)
e2.grid(window, row = 1, column = 1)

assets_text =
e3 = Entry(window, textvariable = assets_text)
e3.grid(row = 2, column = 1)

drugs_text = sorted("[Crack/Cocaine", "Ketermine", "Hash", "Skunk", "heroin", "Morphine", "Acid", "LSD", "Mushrooms", "E", "Opium", "Ritalin", "Steriods", "Spice", "Mkat"])
com4 = Entry(window, text_variable = drugs_text)
com4.grid(row = 3, column = 1)

quantity_text = StringVar()
e5 = Entry(window, textvariable = quantity_text)
e5.grid(row = 4, column = 1)

#define scrollbar
list1 = Listbox(window, height = 25, width = 40)
list1.grid(window, row = 0, column = 2, rowspan = len(drug_list), column = 2)

#attatch scrollbar to list
list1.configure(yscrollcommand = sb1.set)
sbt.configure(command = list1.yview)

b1 = Button(window, text = "Hospital")
b1.bind("<Button-1>", heal)
b1.grid( row = 2, sticky = E)

b2 = Button(window, text = "Next day")
b2.bind("<Button-1>", nday)
b2.grid(row = 2, sticky = E, columnspan = 2)


window.mainloop()