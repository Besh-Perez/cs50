from Tkinter import *
from Tkinter.ttk import combobox

window = Tk()

#Titles
l1 = Label(window, text = "Brand")
l1.grid(row = 0, column = 0)

l1 = Label(window, text = "Upturn")
l1.grid(row = 0, column = 2)

l1 = Label(window, text = "Location")
l1.grid(row = 1, column = 0)

l1 = Label(window, text = "Media")
l1.grid(row = 1, column = 2)

#entires
brand_text = sorted(["kit Kat", "Aero", "Wagon Wheel", "Milky Way"])
com1 = Combobox(window, values = brand_text)
com1.grid(row = 0, column = 1)

upturn_text = StringVar()
e2 = Entry(window, textvariable = upturn_text)
e2.grid(row = 0, column = 3)

location_text = StringVar()
e3 = Entry(window, textvariable = location_text)
e3.grid(row = 1, column = 1)

media_text = StringVar()
e4 = Entry(window, textvariable = media_text)
e4.grid(row = 1, column = 3)


#define scrollbar
list1 = Listbox(window, height = 6, width = 35)
list1.grid(row = 2, column = 0, rowspan = 8, columnspan = 2)

#attaach scrollbar to list
sb1 = Scrollbar(window)
sb1.grid(row = 2, column = 2, rowspan = 8)

list1.configure(yscrollcommand = sb1.set)
sb1.configure(command = list1.yview)

#define buttons
b1 = Button(window, text = "View all", width = 14)
b1.grid(row = 2, column = 3)

b1 = Button(window, text = "Media stores", width = 14)
b1.grid(row = 3, column = 3)

b1 = Button(window, text = "Non-Media stores", width = 14)
b1.grid(row = 4, column = 3)

b1 = Button(window, text = "Remove store", width = 14)
b1.grid(row = 5, column = 3)

b1 = Button(window, text = "Add/Update store", width = 14)
b1.grid(row = 6, column = 3)

b1 = Button(window, text = "Visualise Data", width = 14)
b1.grid(row = 7, column = 3)

b1 = Button(window, text = "Compile Data", width = 14)
b1.grid(row = 8, column = 3)

b1 = Button(window, text = "Close", width = 14)
b1.grid(row = 9, column = 3)




window.mainloop()