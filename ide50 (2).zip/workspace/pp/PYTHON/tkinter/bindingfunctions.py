from tkinter import *

window = Tk()

def printname():
    print("hello my name is beshy")

b1 = Button(window, text = "button 1", command = printname)
b1.pack()



window.mainloop()