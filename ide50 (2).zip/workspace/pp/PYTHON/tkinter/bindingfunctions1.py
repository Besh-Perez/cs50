from tkinter import *

window = Tk()

def printname():
    print("hello my name is beshy")

b1 = Button(window, text = "button 1")
b1.bind("<Button-1>", printname)
b1.pack()



window.mainloop()