from tkinter import *

window = Tk()

topframe = frame(window)
topframe.pack()

bottomframe = frame(window)
bottomframe.pack(side = bottom)

button1 = Button(topframe, text = "button 1", fg = 'red')
button1.pack(side = LEFT)

button2 = Button(topframe, text = "button 2", fg = 'green')
button2.pack(side = LEFT)

button3 = Button(topframe, text = "button 3", fg = 'yellow')
button3.pack(side = LEFT)

button4 = Button(topframe, text = "button 4", fg = 'purple')
button4.pack(side = BOTTOM)

window.mainloop()