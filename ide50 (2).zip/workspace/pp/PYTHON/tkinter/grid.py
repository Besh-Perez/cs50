from tkinter import *

root = Tk()

l1 = Label(root, text = "Name")
l1.grid(row = 0, column = 0, sticky = E)
e1 = Entry(root)
e1.grid(row = 0, column = 1)

l2 = Label(root, text = "Password")
l2.grid(row = 1, column = 0, sticky = E)
e2 = Entry(root)
e2.grid( row = 1, column = 1)

c = Checkbutton(root, text = "keep me logged in")
c.grid(columnspan = 2)

root.mainloop()