from tkinter import *

window = Tk()

l1 = Label(window, text = "Enter", bg = 'yellow', fg = 'blue')
l1.pack()

l1 = Label(window, text = "Start", bg = 'green', fg = 'black')
l1.pack(fill = X)

l1 = Label(window, text = "Exit", bg = 'pink', fg = 'black')
l1.pack(side = LEFT, fill = Y)

window.mainloop()