#include <stdlib.h>
#include <dos.h>

void my_sounds(void);

int music(int pitch, int time)
{
sound(pitch);
delay(time);
nosound();
return(0);
}


void       my_sounds(void)
 {
      music(130, 2000);
      music(137, 2000);
      music(145, 2000);
      music(155, 2000);
      music(166, 2000);
      music(176, 2000);
      music(185, 2000);
      music(195, 2000);
      music(207, 2000);
      music(220, 2000);
      music(235, 2000);
      music(260, 2000);
      music(275, 2000);
      music(290, 2000);
      music(311, 2000);
      music(333, 2000);
      music(350, 2000);
      music(370, 2000);
      music(390, 2000);
      music(415, 2000);
      music(440, 2000);
      music(470, 2000);
      music(490, 2000);
      music(520, 2000);
 }

int main(void) {
  my_sounds();      /* <--- this calls the my_sounds() function */
  return 0;
}