int add_int(int a, int b);

int add_int(int a, int b)
{
    int product = a + b;
    return product;
}