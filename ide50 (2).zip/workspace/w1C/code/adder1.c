#include <stdio.h>
#include <cs50.h>
//declair function
int add_2(int a, int b);

int main(void)
{
    //user input
    printf("enter a number: ");
    int x = get_int();
    printf("another: ");
    int y = get_int();

    int z = add_2(x, y);

    printf("the sum of %i and %i is %i!\n", x, y, z);
}

int add_2(int a, int b)
{
    int sum = a + b;
    return sum;
}