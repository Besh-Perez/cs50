// argv is a program that take the input passed by the user after the run the file using ./[file name]
// i.e. make argv0
// ./argv0 Beshir

#include <cs50.h>
#include <stdio.h>

int main(int argc, string argv[])
{
    if (argc == 2) //argc is arguement count
    {
        printf("hello, %s\n", argv[1]);
    }
    else
    {
        printf("hello, world\n");
    }
}