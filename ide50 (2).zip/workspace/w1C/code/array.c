#include <stdio.h>
#include <cs50.h>

int main(void)
{
    string animals[2]
}