#include <cs50.h>
#include <stdio.h>
#include <string.h>

int main(void)
{
    string s = get_string("Name: ");
    for (int i = 0; i < strlen(s); i++)
    {
       if (s[i] >= 'a' && s[i] <='z')
       {
           printf("%c", s[i] - ('a'-'A')); //should add (int) s[i] but dont need to in this case
       }
       else
       {
           printf("%c", s[i]);
       }
    }
    printf("\n");
}