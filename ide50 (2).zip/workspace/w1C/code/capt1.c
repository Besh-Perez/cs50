//Capitalizes a string

#include <stdio.h>
#include <cs50.h>
#include <string.h>
#include <ctype.h>

int main(void)
{
    string s = get_string("before: ");
    printf("after: ");
    for (int i = 0, n = strlen(s); i < n; i++) // make the interger variable's i = 0 and n = length of input.
    {
        if (islower(s[i]))
        {
            printf("%c", toupper(s[i]));// if the character is lower print it as a character but change to upper.
        }
        else
        {
            printf("%c", s[i]);//if not a lower character print it as it is as a character.
        }
    }
    printf("\n");//printing a new line here makes the program run neatly when testing as it apprears above the CLI
}