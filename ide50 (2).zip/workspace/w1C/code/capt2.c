//Capitalizes a string

#include <stdio.h>
#include <cs50.h>
#include <string.h>
#include <ctype.h>

int main(void)
{
    string s = get_string("before: ");
    printf("after: ");//removed the if statement as we can just convert all characters to upper
    for (int i = 0, n = strlen(s); i < n; i++) // make the interger variable's i = 0 and n = length of input.
    {
        printf("%c", toupper(s[i]));// if the character is lower print it as a character but change to upper.
    }
    printf("\n");//printing a new line here makes the program run neatly when testing as it apprears above the CLI
}