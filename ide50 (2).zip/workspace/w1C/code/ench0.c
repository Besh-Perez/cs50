#include <stdio.h>
#include <cs50>

int main(void)
{   // converts a string into an interger
    string num = "50";
    int i = atoi(num);
}
