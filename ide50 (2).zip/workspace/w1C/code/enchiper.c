#include <stdio.h>
#include <cs50.h>

string encipher(int i = 0, string a; strlen(a) < i; i++);

int main(void)
{
    string key = get_string("enter any characters: ");

}

string encipher(int i = 0, string a; strlen(a) < i; i++)
{
    if (a[i] == ('a'||)
    return a[i]
}