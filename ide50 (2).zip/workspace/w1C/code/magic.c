#include <stdio.h>
#include <cs50.h>

int main(void)
{
    int deck_size = 52;
    for (int i = 0; i < deck_size; i++)
    {
        //deal the card
    }
}