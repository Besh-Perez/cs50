#include <stdio.h>
#include <cs50.h>
// mario walls
int main(void)
{
    int n = get_int("Number: ");
    for (int i = 0; i < n; i++)
    {
        printf("#\n");
    }
}