#include <stdio.h>
#include <cs50.h>

int main(void)
{
    //prompt user for a positive number
    int n; //declare n so the variable can be used
    do
    {
        n = get_int("Positive number: ");
    }
    while ( n <= 0);

    // print out that many blocks
    for (int i = 0; i < n; i++)
    {
        printf("#\n");
    }
}