#include <stdio.h>
#include <cs50.h>
//declaring a function
float multiply_real(float a, float b);

float multiply_real(float a, float b)
{
    float product = a*b;
    return product;
}

