#include <cs50.h>
#include <stdio.h>

int index(int i);
int value;

int main(void)
{
    value = get_int("enter a number here: ");
    int place [] = { index(value) };
}

int index(i)
{
    for (i = 0, int v; value > i; i++)
    {
       return v += i;
    }
}