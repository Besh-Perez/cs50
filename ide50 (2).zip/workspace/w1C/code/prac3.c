#include <stdio.h>
#include <cs50.h>
// argc is the number of commands ie ./greedy 1024 cs50 would be 3
int main (int argc, string argv[]) //if there are 3 lines of code we would say the array contants 3 so argv[2]
{

}