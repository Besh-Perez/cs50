#include <stdio.h>
#include <cs50.h>

bool valid_triangle(double a, double b, double c);

int main(void)
{
    double a1 = get_double("enter a real number: ");
    double b1 = get_double("another: ");
    double c1 = get_double("last one: ");
    if(valid_triangle(a1, b1, c1) == true)
    {
        printf("True!\n");
    }
    else
    {
        printf("False\n");
    }
}

bool valid_triangle(double a, double b, double c)
{
    while ((a > 0) && (b > 0) && (c > 0));
    if((a + b > c) || (a + c > b) || (c + b > a))
    {
        return true;
    }
    else
    {
        return false;
    }
}