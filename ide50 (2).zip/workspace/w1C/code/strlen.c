#include <cs50.h> //help50 make [file name]
#include <stdio.h>

int main(void)
{
    string s = get_string("name: ");
    int n = 0;
    while (s[n] != '\0')
    {
        n++;
    }
    printf("%i\n", n);//remember the interger or '%i' must take an arguement in this case n
}