#include <cs50.h>
#include <stdio.h>
#include <string.h>

int main(void)
{
    string s = get_string("Name: ");
    for (int i = 0; i < strlen(s); i++)
    {
        //get the character and the interger
        // essentially asking for the character or s[i] and convering it to an interger itself
        printf("%c %i\n", s[i], (int) s[i]);
    }
}