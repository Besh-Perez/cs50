#include <cs50.h>
#include <stdio.h>
#include <string.h>
#include <ctype.h>

int main (int argc, string argv[])
{
    int key = atoi(argv[1]);
    if ((argc != 2) || (key < 0))
    {
        return 1;
        printf("sorry invalid input!");
    }
    else
    {
        string s = get_string("enter a phrase!: ");
        for (int i = 0, n = strlen(s); i < n; i++)
        {
             if islower(s[i])
             {
                printf("%c", (((s[i] + key) - 97) % 26) + 97);
             }
             else if isupper(s[i])
             {
                printf("%c", (((s[i] + key) - 65) % 26) + 65);
             }
             else
             {
                 printf("%c", s[i]);
             }
        }
        printf("\n");
        return 0;
    }
}