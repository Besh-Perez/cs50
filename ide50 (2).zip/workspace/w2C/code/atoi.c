#include <stdio.h>
#include <stdlib.h>
#include <cs50.h>
#include <string.h>
#include <ctype.h>

int main(void)
{
    int val = atoi('A');
    printf("the value of A is %i\n", val);

}