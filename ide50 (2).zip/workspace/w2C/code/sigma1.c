#include <cs50.h>
#include <stdio.h>

int sigma(int m);

int main(void)
{
    int n;
    do
    {
        n = get_int("enter an interger: ");
    }
    while (n < 1);
    int answer = sigma(n);
    printf("%i\n", answer);
}

//return sum of 1 through m
int sigma(int m)
{
    if (m <= 0)
    {
        return 0;
    }
    else
    {
        //think of it as its the highest number then you go back into the function and the first if statement acts as a breaker if you will for
        //addition so if  it was 10 it would be 10 + 9 + 8 +... + 1 = 55 as 3 would be 3 + 2 + 1 = 6
        return (m + sigma(m - 1));
    }
}