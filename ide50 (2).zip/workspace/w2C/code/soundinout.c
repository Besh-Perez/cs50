#include <cs50.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>

// make a alg that takes the arguements for the argv[1] which will contain a .txt file.
//find the addresss of said file and itterate through it to determine if the file is not of a strlen() = 7 || 8.
// if not then. assign argv[1] to a pointer


int freq;

int main(int argc, string argv[])
{
    FILE* ptr1 = fopen(argv[1], "r";
    for (int i =0, n =strlen(pfreq); i < n; i++)
        if(strlen(pfreq[i]) != ((7 || 8) && (strlen(pfreq[i]) > 0);
            return 0;
            printf("sorry the attachted file is not collaberated correctly: ");

        else if (strlen(pfreq[i]) == 7)



}