#include <stdio.h>
#include <cs50.h>
#include <string.h>
#include <ctype.h>


int main(void)
//get a sting name using the cs50 header/library
{
    string name = get_string("Name :");
    char initials[4];
    int counter = 0;
    for (int i = 0; i < strlen(name); i++)
    {
        if (isupper(name[i]))
        {
            initials[counter] = name[i];
            counter ++;
        }
    }
    initials[counter] = '\0';
    printf("%s\n", initials);
}
// use help50 for help
//use style 50 to find out about commments