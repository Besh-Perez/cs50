#include <stdio.h>
#include <cs50.h>
#include <string.h>
#include <ctype.h>
#include <stdlib.h>
#include <dos.h>
#include <math.h>

void sounds(void);

float key (char let);

int loc (int lenn, int j);    //functions all declared

float octive (float L, int O);

int dur (int fract1, int fract2);

int main (int argc, char* argv[])
{
    if (argc <= 1)
    {
        return 1;
        printf("in order for this program to work you must assign a .txt file\n");
    }
    else
    {
        char* plybk = argv[1];
        FILE* bdayptr = fopen(plybk, "r");
        if (bdayptr == NULL)
        {
            printf("the attactched file appears empty\n");
        }
        else
        {
            int n = 0;
            char ch;
            do
            {
                n++;
            }
            while ((ch = fgetc(bdayptr)) != EOF);

            char* arrs = malloc(n * sizeof(char));
            fread(arrs, sizeof(char), n, bdayptr);

            for (int i = 0, j = 20; i <= j; i++)
            {
                int frequency, duration;
                sound(frequency);
                delay(duration);

                char* note = &arrs[i];
                int leng = strlen(&note[i]);
                frequency = octive(key(note[0]), atoi(&note[(loc(leng, 1))]));          //i know this looks mad but i figure it should
                duration = dur(atoi(&note[loc(leng, 3)]), atoi(&note[loc(leng, 5)]));

            }
            nosound();
            return 0;
            fclose(bdayptr);// as soon as possible to free up memory.
         }
    }
}
float key (char let)
{
    float freq;
    if toupper(let) == 'A';
    {
        freq = 440;                   // this Alorithm takes the note and assignes a value to it. then depending
    }                                               // on the octive
    else if toupper(let) == 'B';
    {
        freq = 493.883;
    }
    else if toupper(let) == 'C';
    {
        freq = 261.626;
    }
    else if toupper(let) == 'D';
    {
        freq = 293.665;
    }
    else if toupper(let) == 'E';
    {
        freq = 329.628;
    }
    else if toupper(let) == 'F';
    {
        freq = 349.228;
    }
    else if toupper(let) == 'G';
    {
        freq = 391.995;
    }
    else
    {
        freq = 0;
    }
    return freq;
}

int dur(int fract1, int fracr2)
{
    int milli;
    milli = ((fract1 * 1000) / fract2);
    return milli;
}

int loc ( int lenn, int x)
{
    int loca;

    if (int lenn == 7)
    {
        loca = x;
    }
    else
    {
        loca = (x + 1);
    }
    return loca;
}


float octive (float L, int O)
{
    int result;

    if (O >= 4)
    {
        result = (L * pow(2, (O - 4));
    }
    else
    {
        result = (L / pow(2, (4 - O));
    }
    return result;
}
