#include <stdio.h>
#include <dos.h>
#include <cs50.h>
#include <stdlib.h>
#include <ctype.h>
#include <string.h>

int x = 0;
int y = 0;

#define t(125);

void mysound(void);

int sound (int freq, int dur)
{
    int freq();
    int dur();
    nosound();
    return 0;
}

void mysound(void)
{
    freq(x);
    dur(y*t);
    nosound();
    return 0;
}