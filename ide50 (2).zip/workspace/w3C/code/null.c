#include <stdio.h>
#include <cs50.h>
#include <string.h>
#include <ctype.h>

int main(void)
{
    // get a string
    char *s = get_string("s: ");
    if (s == NULL)
    {
        return 1;
    }

    //allocate memory for another string
    char *t = malloc((strlen(s) + 1) * sizeof(char)); //malloc - memory allocation
    if (!s) //same as s == NULL                       //it takes one arguement the number of bytes you want
    {                                                 //the os's purpose is hand you back a chunk
        return 1;
    }

    //copy string into memory
    for (int i = 0, n; n = strlen(s); i <= n; i++)    // <= instead of < again to account for NULL
    {
        t[i] = s[i];
    }

    //capitilise the letter in copy
    if(islower(t))
    {
        t[0] = toupper(t[0]);
    }
    //print check
    printf("s: %s/n", s);
    printf("t: %S\n", t);
    }
    //free memory
    free(t);
    return 0;
}