#include <cs50.h>
#include <stdio.h>
#include <string.h>
#include <stdlib.h>

int main (int argc, char* argv[])
{
    if (argc <= 1)
    {
        return 1;
        printf("in order for this program to work you must assign a .txt file\n");
    }
    else
    {
        char* bmim = argv[1];
        FILE* bmimage = fopen(bmim, "r");
        if (bmimage == NULL)
        {
            printf("the attactched file appears empty\n");
        }
        else
        {
            int n = 0;
            char ch;
            do
            {
                n++;
            }
            while ((ch = fgetc(bdayptr)) != EOF);

            char* arrs = malloc(n * sizeof(char));
            fread(arrs, sizeof(char), n, bdayptr);

            for (int i = 0, j = 20; i <= j; i++)
            {
                int frequency, duration;
                sound(frequency);
                delay(duration);

                char* note = &arrs[i];
                int leng = strlen(&note[i]);
                frequency = octive(key(note[0]), atoi(&note[(loc(leng, 1))]));          //i know this looks mad but i figure it should
                duration = dur(atoi(&note[loc(leng, 3)]), atoi(&note[loc(leng, 5)]));

            }
            nosound();
            return 0;
            fclose(bdayptr);// as soon as possible to free up memory.
         }
    }