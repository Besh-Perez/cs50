#include <cs50.h>
#include <stdio.h>
#include <string.h>

int main(char *bar)
{
    char c[12]; //allocate an array size 12
    memcpy (c, bar, strlen(bar)); //gonna copy into c, whatever is in bar up to strlen(bar) bites
}

int main (int argc, char *argv[])
{
    foo(argv[1]);
}