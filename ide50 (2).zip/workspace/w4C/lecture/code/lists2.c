//implements a linked list before i know the size

#include <cs50..h>
#include <stdio.h>

typedef struct node
{
    int number;                 //the idea here is we dont want a structure inside a structure
    struct node *next;          //instead each of these structures has a pointer to someone else.
}

int main (void)
{
    // memory for numbers
    node *numbers = NULL;   //how too allocate an array before i know the size of it

    // prompt for numbers (entil EOF)
    while (true)
    {
        //prompt for number
        int number = get_int("number: ");

        // check for EOF
        if (number == INT_MAX)
        {
            break;
        }

        //check whether number is already in list
        bool found = false;
        for (node *ptr = numbers; ptr !=NULL ;ptr = ptr->next)
        {
            if (ptr->number == number)
            {
                found = true;
                break;
            }
        }

        //if number not found in list, add to list.
        if (!found)
        {
            // allocate space for number
            node *n = malloc(sizeof(n));
            if (!n)
            {
                return 1;
            }
            //add number to list
            n->number = number;
            n->next = NULL;
            if (numbers)
            {
                for(node *ptr = numbers; ptr!=NULL;ptr = ptr->next)
                {
                    if (!ptr->next)
                    {
                        ptr->next = n;
                        break;
                    }
                }
            }
            else
            {
                numbers = n;
            }

        }
    }

    // print numbers
    printf("%i\n", ptr->numbers);

    //free memory
    node *ptr = ptr->next;
    while (ptr != NULL)
    {
        node *next = ptr->next;
        free(ptr);
        ptr = next;
    }
}