typedef struct
{
    char* name;
    char* dorm;
}
student;