from cs50 import get_string

s = get_string("S: ")
t = get_string("t: ")

if s == t:
    print ("same")
else:
    print("different")