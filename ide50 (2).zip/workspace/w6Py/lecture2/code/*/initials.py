from cs50 import get_string

def main():
    string = get_string("enter a Full Name: ")
    initials = ""

    for i in string:
       if i.isupper():
           initials += i
    print(initials)

if __name__ == "__main__":
    main()