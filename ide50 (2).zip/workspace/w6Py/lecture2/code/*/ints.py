from cs50 import get_int

# prompt user for x
x = get_int("x: ")

# prompt user for y
y = get_int("y: ")

#preform arithmatic
print(f"if you add {x} & {y} you get {x + y}")
print(f"if you take {y} from {x} you get {x - y}")
print(f"if you multiply {x} & {y} you get {x * y}")
print(f"if you truly divide {x} by {y} you get {x / y}")
print(f"if you floor divide {x} by {y} you get {x // y}")
print(f"remainder of {x} devided by {y} is {x % y}")