name = input("enter your name: ")
names = name.split()
initials = ""

for c in names:
    initials += c[0].upper()

print("hello", initials)