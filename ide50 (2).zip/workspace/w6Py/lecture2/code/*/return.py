from cs50 import get_int

def main():
    x = get_int("number: ")
    print(squared(x))

def squared(n):
    return n**2

if __name__ == "__main__":
    main()