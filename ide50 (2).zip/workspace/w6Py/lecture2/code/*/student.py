class Student:
    def __init__(self, name, dorm):
        self.name = name
        self.dorm = dorm