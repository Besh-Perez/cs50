import sys

for s in sys.argv:
    print(s)