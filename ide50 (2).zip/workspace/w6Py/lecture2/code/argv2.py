import sys

for s in sys.argv:
    for c in s:
        print(c)