from cs50 import get_int

def main():
    x = get_int("x: ")
    y = get_int("y: ")

    if (x > y):
        print(f"{x} is a bigger number than {y}")
    elif (x < y):
        print(f"{y} is bigger than {x}")
    else:
        print("both values are equal")

if __name__ == "__main__":
    main()