from cs50 import get_string

s = get_string("enter a string: ")
print(f"hello, {s}") #or print(f"hello, {}".format(s))