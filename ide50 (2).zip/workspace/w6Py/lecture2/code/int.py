from cs50 import get_int

def main():

    i = get_int("integer: ")
    print(f"hello, {i}")

if __name__ == "__main__":
    main()