import sys
from cs50 import get_string

book = ["Kaddy", "Pepe", "Dizz", "Bush", "Kamal", "Nafisa", "Ali", "Amy", "Claudia", "Samual"]

name = get_string("enter a name: ").title()

if name in book:
    book.remove(name)
else:
    book.append(name)

print(book)