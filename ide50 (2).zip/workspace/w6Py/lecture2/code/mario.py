for i in range(4):
    print("?", end="")
print()