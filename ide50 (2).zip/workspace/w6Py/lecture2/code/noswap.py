x = 1
y = 2

print("x is", x, "and y is", y)
x, y = y, x
print(f"x is {x} and y is {y}")