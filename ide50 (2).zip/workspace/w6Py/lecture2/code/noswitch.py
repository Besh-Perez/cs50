from cs50 import get_char

def main():
    c = get_char("answer: ").upper()
    if c == "Y":
        print("yes")
    elif c == "N":
        print("no")
    else:
        print("invalid input either 'Y' or 'N'")
        return main()
if __name__ == "__main__":
    main()
