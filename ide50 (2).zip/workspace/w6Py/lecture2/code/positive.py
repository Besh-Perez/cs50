from cs50 import get_int

def main():
    num = get_int("enter a positive integer: ")
    if (check(num) == True):
        print(f"{num}")
    else:
        print("number is not positive")
        return main()

def check(x):
    if x > 0:
        return True

if __name__ == "__main__":
    main()