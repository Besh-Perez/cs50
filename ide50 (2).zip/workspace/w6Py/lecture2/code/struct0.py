from cs50 import get_string

students = list()

for i in range(3):
    name = input("Name: ")
    dorm = input("dorm: ")
    students.append(name, dorm)
    print(f"studdents {name}\n")

print(students)