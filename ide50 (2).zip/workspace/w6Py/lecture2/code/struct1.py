from cs50 import get_string
from student import Student

students = list()
dorm = list()

for i in range(3):
    name = input("Name: ")
    dorm = input("dorm: ")
    s = Student(name, dorm)
    students.append(s)
    
for student in students:
    print(f"{student.name} lives in {student.dorm}")