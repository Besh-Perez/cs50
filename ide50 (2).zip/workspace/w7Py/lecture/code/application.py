from flask import Flask
#instead of server.py
app = Flask(__name__)

if request if for /
    then send back home page
else if request is for /zuck
    then send mark's home page
else if request is for /login
    then prompt user to log in