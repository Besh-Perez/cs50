from flask import Flask
#instead of server.py
app = Flask(__name__)

if request if for /
    then send back index.html
else if request is for /zuck
    then send zuck.html
else if request is for /login
    then show user login.html