from flask import Flask, render_template, request, smtplib, login, sendmail

#configure app
app= Flask(__name__)

# Registrants
students = []

@app.route("/")
def index():
    return render_template("index.html")



@app.route("/registrants")
def registrants():
    return render_template("registrants.html", students=students)

@app.route("/register", methods=["POST"])
def register():
    name = request.form.get("name")
    email = request.form.get("email")
    dorm = request.form.get("dorm")
    if not name or not dorm or not email:
        return render_template("failure.html")
    message = "you are registed!"
    server = smtplib.SMTP("smtp.gmail.com", 587)
    server.starttls()
    server.login("jharvard@cs50.net", os.getenv("PASSWORD"))
    server.sendmail("jharvard@cs50.net", email, message)
    return render_template