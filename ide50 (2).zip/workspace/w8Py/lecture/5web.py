import sys #command line arguments

from cs50 import SQL

db = SQL("sqlite:///lecture.db")

rows = db.execute("SELECT * FROM Album WHERE :t", t = argv[1])

#for each album in database
for row in rows:

    #print title of album
    print(row["Title"])

#query database for all albums
#for each album in database
#   print title of album