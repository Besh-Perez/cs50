DIM FourDigitPassword INTEGER
FOR i = 0 TO 9
    FOR j = 0 TO 9
        FOR k = 0 TO 9
            FOR k = 0 TO 9
                FourDigitPassword = getFourDigits {i, j, k, l}
                IF checkPasswordMatch(FourDigitPassword) = TRUE THEN
                        GOTO 140
                END
            NEXT l
        NEXT k
    NEXT j
NEXT i
PRINT FourDigitPassword
END