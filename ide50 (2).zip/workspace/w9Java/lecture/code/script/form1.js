let form = document.getElementById("registration");
form.onsubmit = function() {

    if (form.email.value == "")
    {
        alert("missing email");
        return false;
    }
    else if (form.password.value == "")
    {
        alert("missing password");
        return false;
    }
    else if (form.passwprd.length < 8)
    {
        alert("password too short")
        return false
    }
    else if (form.password.value != form.confirmation.value)
    {
        alert("passwords don't match");
        return false;
    }
    else if (!form.agreement.value)
    {
        alert("you have not clicked agree!");
        return false;
    }
    else
    {
        return true;
    }
};